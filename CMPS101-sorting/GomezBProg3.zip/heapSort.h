/******************************
 * By: Brandon Gomez (brlgomez)
 *****************************/

void heapSort(int keys[], int numKeys);
