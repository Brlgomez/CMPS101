/* Looked up code on rossetacode */

void insertionSort(int keys[], int numKeys);
